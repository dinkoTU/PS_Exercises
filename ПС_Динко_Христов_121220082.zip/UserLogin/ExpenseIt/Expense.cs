﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ExpenseIt
{
    public class Expense
    {
        public string ExpenseType { get; set; }
        public double ExpenseAmount { get; set; }
    }
}
