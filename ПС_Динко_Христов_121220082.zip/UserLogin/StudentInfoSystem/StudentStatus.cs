﻿namespace StudentInfoSystem
{
    public enum StudentStatus
    {
        Redoven, 
        SamostoiatelnaPodgotovka, 
        Zadochno, 
        PrekasnalPoUspeh, 
        PrekasnalPoBolest, 
        PrekasnalPoMaichinstvo
    }
}