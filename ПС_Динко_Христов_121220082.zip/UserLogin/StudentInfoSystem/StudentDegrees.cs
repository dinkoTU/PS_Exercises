﻿namespace StudentInfoSystem
{
    public enum StudentDegrees
    {
        BACHELOR, 
        MASTER, 
        Doctor
    }
}