﻿using System;
using System.Collections.Generic;
using System.Text;

namespace StudentInfoSystem
{
    class StudentData
    {
        static List<Student> _TestStudents = new List<Student>();
        static public List<Student> TestStudents
        {
            get
            {
                ResetTestStudentData();
                return _TestStudents;
            }
            private set { }
        }

        static private void ResetTestStudentData()
        {
            _TestStudents.Clear();

            _TestStudents.Add(new Student
            {
                FirstName = "Иван",
                SurName = "Иванов",
                LastName = "Иванов",
                Facultee = "ФКСТ",
                Specialtee = "КСИ",
                FacNumber = "121220079",
                Degree = StudentDegrees.Doctor,
                Course = 2,
                Group = 41,
                Stream = 9,
                Status = StudentStatus.Redoven,
                Username = "Ivancho"
            });

            _TestStudents.Add(new Student
            {
                FirstName = "Георги",
                SurName = "Иванов",
                LastName = "Петров",
                Facultee = "ФКСТ",
                Specialtee = "КСИ",
                FacNumber = "121220099",
                Degree = StudentDegrees.BACHELOR,
                Course = 5,
                Group = 42,
                Stream = 9,
                Status = StudentStatus.SamostoiatelnaPodgotovka,
                Username = "Gosheto"
            });
            _TestStudents.Add(new Student
            {
                FirstName = "Алфонсо",
                SurName = "Американо",
                LastName = "Дейвис",
                Facultee = "СЕЕП",
                Specialtee = "РЕ",
                FacNumber = "121220110",
                Degree = StudentDegrees.MASTER,
                Course = 6,
                Group = 40,
                Stream = 15,
                Status = StudentStatus.Redoven,
                Username = "Alfonso"
            });
            _TestStudents.Add(new Student
            {
                FirstName = "Димитър",
                SurName = "Димитричкин",
                LastName = "Димитричков",
                Facultee = "ФКСТ",
                Specialtee = "ИТИ",
                FacNumber = "121220002",
                Degree = StudentDegrees.BACHELOR,
                Course = 8,
                Group = 61,
                Stream = 12,
                Status = StudentStatus.Zadochno,
                Username = "Dimitrichko"
            });
        }
    }
}
